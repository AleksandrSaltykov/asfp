# ASFP React WMS

## Установка

```bash
npm install
npm run dev
```